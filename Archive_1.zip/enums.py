import enum


class OUT_TYPES(enum.StrEnum):
    webp = enum.auto()
    png = enum.auto()
    svg = enum.auto()
